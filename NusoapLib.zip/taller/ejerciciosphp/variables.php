<?php
    //Variables
    /*
        Las variables se representan con un signo de dólar 
        seguido por el nombre de la variable. 
        El nombre de la variable es sensible a minúsculas y mayúsculas
    */
    echo "Hola Mundo";
?>