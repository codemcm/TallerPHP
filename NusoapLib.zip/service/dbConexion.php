<?php
	//mysqli_connect(URL, USER, PASS, DB)
	$conectar = mysqli_connect("localhost", "root", "", "webservice") 
	or die("Error " . mysqli_error($conectar));
?>
